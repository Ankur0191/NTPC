"use client";
import { Box, Button, Typography, Container } from "@mui/material";
import { useRouter } from "next/navigation";

export default function LandingPage() {
  const router = useRouter();

  return (
    <Container maxWidth="lg">
      <Box display="flex" flexDirection="column" alignItems="center" textAlign="center" height="100vh" justifyContent="center">
        <Typography variant="h2" fontWeight="bold" gutterBottom>
          AI-Powered Renewable Energy Forecasting
        </Typography>
        <Typography variant="h6" color="gray" mb={3}>
          Predict solar and wind energy generation using AI models with real-time insights.
        </Typography>
        <Button variant="contained" color="primary" size="large" onClick={() => router.push("/dashboard")}>
          Go to Dashboard
        </Button>
      </Box>
    </Container>
  );
}
