"use client";
import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Paper, Typography } from "@mui/material";

const mockData = [
  { time: "10 AM", solar: 3.1, wind: 2.5 },
  { time: "11 AM", solar: 4.0, wind: 2.9 },
  { time: "12 PM", solar: 5.2, wind: 3.8 },
];

export default function ForecastChart() {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return <Typography>Loading Chart...</Typography>;

  return (
    <Paper sx={{ p: 2, background: "#1e1e1e", color: "#fff" }}>
      <Typography variant="h6" gutterBottom>
        Energy Generation Trends
      </Typography>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={mockData}>
          <XAxis dataKey="time" stroke="#90caf9" />
          <YAxis stroke="#90caf9" />
          <Tooltip />
          <Line type="monotone" dataKey="solar" stroke="orange" strokeWidth={2} />
          <Line type="monotone" dataKey="wind" stroke="lightblue" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </Paper>
  );
}
