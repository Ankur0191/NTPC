"use client";
import { Box, Typography } from "@mui/material";

export default function Settings() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5">Settings</Typography>
      <Typography variant="body1">Customize your experience here.</Typography>
    </Box>
  );
}
