"use client";
import { Drawer, List, ListItem, ListItemIcon, ListItemText } from "@mui/material";
import { Home, BarChart, Settings } from "@mui/icons-material";
import { useRouter } from "next/navigation";

const menuItems = [
  { text: "Dashboard", icon: <Home />, path: "/dashboard" },
  { text: "Analytics", icon: <BarChart />, path: "/dashboard/analytics" },
  { text: "Settings", icon: <Settings />, path: "/dashboard/components/Settings" },
];

export default function Sidebar() {
  const router = useRouter();

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 250,
        "& .MuiDrawer-paper": { width: 250, background: "#1e1e1e", color: "#fff" },
      }}
    >
      <List>
        {menuItems.map((item) => (
          <ListItem
            key={item.text}
            component="div"
            onClick={() => router.push(item.path)}
            sx={{ cursor: "pointer", "&:hover": { background: "#333" } }}
          >
            <ListItemIcon sx={{ color: "#90caf9" }}>{item.icon}</ListItemIcon>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
}
