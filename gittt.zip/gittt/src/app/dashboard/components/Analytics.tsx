"use client";
import { Card, CardContent, Typography } from "@mui/material";

export default function Analytics() {
  return (
    <Card sx={{ background: "#1e1e1e", color: "#fff", p: 2 }}>
      <CardContent>
        <Typography variant="h6">Energy Insights</Typography>
        <Typography variant="body1">Solar Output: 5.2 MW (+3.5%)</Typography>
        <Typography variant="body1">Wind Output: 3.8 MW (-1.2%)</Typography>
      </CardContent>
    </Card>
  );
}
