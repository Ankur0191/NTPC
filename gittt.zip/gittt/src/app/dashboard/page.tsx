"use client";
import { Grid, Box } from "@mui/material";
import ForecastChart from "./components/ForecastChart";
import Analytics from "./components/Analytics";
import Sidebar from "./components/Sidebar"; // Import Sidebar

export default function DashboardPage() {
  return (
    <Box display="flex">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <Box flex={1} p={3}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <ForecastChart />
          </Grid>
          <Grid item xs={12} md={4}>
            <Analytics />
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}
