"use client";
import { UserButton, useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import Sidebar from "./components/Sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { isSignedIn, isLoaded } = useUser();
  const router = useRouter();

  if (!isLoaded) return <p>Loading...</p>;
  if (!isSignedIn) {
    router.push("/sign-in");
    return null;
  }

  return (
    <div style={{ display: "flex" }}>
      <Sidebar />
      <div style={{ flexGrow: 1, padding: "20px" }}>
        <UserButton /> {/* Shows sign-out option */}
        {children}
      </div>
    </div>
  );
}
