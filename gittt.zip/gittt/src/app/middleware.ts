import { ClerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

const isPublicRoute = createRouteMatcher(["/"]); // Define public routes

import { NextRequest } from "next/server";

export default ClerkMiddleware((auth: any, req: NextRequest) => {
  if (isPublicRoute(req)) {
    return auth().protect(false);
  }
  return auth().protect();
});

// Match all routes except static files and Next.js internals
export const config = {
  matcher: ["/((?!.*\\..*|_next).*)"],
};
