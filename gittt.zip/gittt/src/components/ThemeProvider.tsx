"use client";
import { createTheme, ThemeProvider, CssBaseline } from "@mui/material";
import { ReactNode, useState, useEffect } from "react";

const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: { main: "#90caf9" },
    secondary: { main: "#f48fb1" },
    background: { default: "#121212", paper: "#1e1e1e" },
  },
  typography: { fontFamily: "Inter, sans-serif" },
});

export default function CustomThemeProvider({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
}
